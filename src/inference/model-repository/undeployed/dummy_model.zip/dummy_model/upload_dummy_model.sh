#!/bin/sh

# Global Classifier Dummy Model Upload Script
# This script uploads dummy model files to test and production environments using S3-Ferry
# Compatible with BusyBox ash shell

set -e  # Exit on any error

script_name=$(basename $0)
echo "$(date -u +"%Y-%m-%d %H:%M:%S") - $script_name started"

# Set default values if not provided by constants.ini
S3_FERRY_URL=${GLOBAL_CLASSIFIER_S3_FERRY:-"http://gc-s3-ferry:3000"}

# Dummy model configuration
DUMMY_MODEL_ID=${DUMMY_MODEL_ID:-"dummy"}
DUMMY_MODEL_NAME="dummy-model"

# Get the directory where this script is located (BusyBox compatible)
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "$(date -u +"%Y-%m-%d %H:%M:%S") - Script directory: $SCRIPT_DIR"

# Function to check if S3-Ferry is running and wait until it's available
wait_for_s3_ferry() {
    echo "$(date -u +"%Y-%m-%d %H:%M:%S") - Checking S3-Ferry service availability at $S3_FERRY_URL"
    
    max_attempts=30  # Maximum 60 seconds (30 attempts * 2 seconds)
    attempt=1
    
    while [ $attempt -le $max_attempts ]; do
        echo "$(date -u +"%Y-%m-%d %H:%M:%S") - Attempt $attempt/$max_attempts: Testing S3-Ferry connection..."
        
        # Try to reach S3-Ferry service - check root endpoint or documentation
        if command -v wget >/dev/null 2>&1; then
            # Try with wget (BusyBox compatible)
            if wget -q --timeout=10 --tries=1 -O /dev/null "$S3_FERRY_URL/" 2>/dev/null || \
               wget -q --timeout=10 --tries=1 -O /dev/null "$S3_FERRY_URL/documentation" 2>/dev/null; then
                echo "$(date -u +"%Y-%m-%d %H:%M:%S") - S3-Ferry service is now available!"
                return 0
            fi
        else
            echo "$(date -u +"%Y-%m-%d %H:%M:%S") - ERROR: Neither curl nor wget available for health check"
            return 1
        fi
        
        echo "$(date -u +"%Y-%m-%d %H:%M:%S") - S3-Ferry not ready yet, waiting 2 seconds..."
        sleep 2
        attempt=$((attempt + 1))
    done
    
    echo "$(date -u +"%Y-%m-%d %H:%M:%S") - ERROR: S3-Ferry service did not become available after $max_attempts attempts"
    echo "$(date -u +"%Y-%m-%d %H:%M:%S") - Please ensure S3-Ferry container is running at $S3_FERRY_URL"
    return 1
}

# Wait for S3-Ferry to be available before proceeding
if ! wait_for_s3_ferry; then
    echo "$(date -u +"%Y-%m-%d %H:%M:%S") - Exiting due to S3-Ferry unavailability"
    exit 1
fi

echo "$(date -u +"%Y-%m-%d %H:%M:%S") - Uploading dummy model files to test and production environments"

# Function to call S3-Ferry API (BusyBox compatible)
call_s3_ferry() {
    source_path="$1"
    source_type="$2"
    dest_path="$3"
    dest_type="$4"
    
    # Create JSON payload using printf (more portable than cat with heredoc)
    payload=$(printf '{"sourceFilePath":"%s","sourceStorageType":"%s","destinationFilePath":"%s","destinationStorageType":"%s"}' \
        "$source_path" "$source_type" "$dest_path" "$dest_type")
    
    echo "$(date -u +"%Y-%m-%d %H:%M:%S") - S3-Ferry transfer: $source_path ($source_type) -> $dest_path ($dest_type)"
    
    # Use wget if available, fallback to curl
    if command -v curl >/dev/null 2>&1; then
        response=$(curl -s -w "\n%{http_code}" \
            -X POST \
            -H "Content-Type: application/json" \
            -d "$payload" \
            "$S3_FERRY_URL/v1/files/copy")

    elif command -v wget >/dev/null 2>&1; then
        # BusyBox wget approach
        response=$(wget -q -O - --post-data="$payload" \
            --header="Content-Type: application/json" \
            "$S3_FERRY_URL/v1/files/copy" 2>&1 || echo "ERROR")
    else
        echo "$(date -u +"%Y-%m-%d %H:%M:%S") - ERROR: Neither curl nor wget available"
        return 1
    fi
    
    # Extract HTTP code (last line for curl)
    if command -v curl >/dev/null 2>&1; then
        http_code=$(echo "$response" | tail -n1)
        response_body=$(echo "$response" | head -n -1)
    else
        # For wget, check if response contains error
        if echo "$response" | grep -q "ERROR"; then
            http_code="500"
            response_body="$response"
        else
            http_code="200"
            response_body="$response"

        echo "$(date -u +"%Y-%m-%d %H:%M:%S") - HTTP Code: $http_code, Response: $response_body"
        fi
    fi
    
    # Check if HTTP code indicates success
    case "$http_code" in
        200|201)
            echo "$(date -u +"%Y-%m-%d %H:%M:%S") - S3-Ferry transfer successful (HTTP $http_code)"
            return 0
            ;;
        *)
            echo "$(date -u +"%Y-%m-%d %H:%M:%S") - ERROR: S3-Ferry transfer failed (HTTP $http_code): $response_body"
            return 1
            ;;
    esac
}

# Function to upload dummy model files to specific environment (BusyBox compatible)
upload_dummy_model() {
    environment="$1"
    s3_base_path="models/${environment}/modelId-${DUMMY_MODEL_ID}"
    
    echo "$(date -u +"%Y-%m-%d %H:%M:%S") - Uploading dummy model to $environment environment..."
    
    # Upload config.pbtxt
    local_file_path="${SCRIPT_DIR}/config.pbtxt"
    s3_dest_path="${s3_base_path}/${DUMMY_MODEL_NAME}/config.pbtxt"
    
    # Check if local file exists
    if [ ! -f "$local_file_path" ]; then
        echo "$(date -u +"%Y-%m-%d %H:%M:%S") - ERROR: Local file not found: $local_file_path"
        return 1
    fi
    
    # Upload config.pbtxt via S3-Ferry
    if ! call_s3_ferry "$local_file_path" "FS" "$s3_dest_path" "S3"; then
        echo "$(date -u +"%Y-%m-%d %H:%M:%S") - ERROR: Failed to upload config.pbtxt to $environment environment"
        return 1
    fi
    
    # Upload model.py
    local_file_path="${SCRIPT_DIR}/1/model.py"
    s3_dest_path="${s3_base_path}/${DUMMY_MODEL_NAME}/1/model.py"
    
    # Check if local file exists
    if [ ! -f "$local_file_path" ]; then
        echo "$(date -u +"%Y-%m-%d %H:%M:%S") - ERROR: Local file not found: $local_file_path"
        return 1
    fi
    
    # Upload model.py via S3-Ferry
    if ! call_s3_ferry "$local_file_path" "FS" "$s3_dest_path" "S3"; then
        echo "$(date -u +"%Y-%m-%d %H:%M:%S") - ERROR: Failed to upload model.py to $environment environment"
        return 1
    fi
    
    echo "$(date -u +"%Y-%m-%d %H:%M:%S") - Successfully uploaded dummy model to $environment environment"
    return 0
}

# Main execution (BusyBox compatible)
main() {
    echo "$(date -u +"%Y-%m-%d %H:%M:%S") - Starting dummy model upload process"
    
    # Verify required files exist
    if [ ! -f "${SCRIPT_DIR}/config.pbtxt" ]; then
        echo "$(date -u +"%Y-%m-%d %H:%M:%S") - ERROR: config.pbtxt not found in ${SCRIPT_DIR}"
        exit 1
    fi
    
    if [ ! -f "${SCRIPT_DIR}/1/model.py" ]; then
        echo "$(date -u +"%Y-%m-%d %H:%M:%S") - ERROR: model.py not found in ${SCRIPT_DIR}"
        exit 1
    fi
    
    echo "$(date -u +"%Y-%m-%d %H:%M:%S") - Dummy model files found:"
    echo "$(date -u +"%Y-%m-%d %H:%M:%S") - - config.pbtxt: $(ls -lh "${SCRIPT_DIR}/config.pbtxt" 2>/dev/null || echo "file exists")"
    echo "$(date -u +"%Y-%m-%d %H:%M:%S") - - model.py: $(ls -lh "${SCRIPT_DIR}/model.py" 2>/dev/null || echo "file exists")"
    
    # Upload to testing environment
    echo "$(date -u +"%Y-%m-%d %H:%M:%S") - Step 1: Uploading to testing environment..."
    if ! upload_dummy_model "testing"; then
        echo "$(date -u +"%Y-%m-%d %H:%M:%S") - ERROR: Failed to upload dummy model to testing environment"
        exit 1
    fi
    
    # Upload to production environment
    echo "$(date -u +"%Y-%m-%d %H:%M:%S") - Step 2: Uploading to production environment..."
    if ! upload_dummy_model "production"; then
        echo "$(date -u +"%Y-%m-%d %H:%M:%S") - ERROR: Failed to upload dummy model to production environment"
        exit 1
    fi
    
    echo "$(date -u +"%Y-%m-%d %H:%M:%S") - Dummy model upload completed successfully"
    echo "$(date -u +"%Y-%m-%d %H:%M:%S") - Model available at:"
    echo "$(date -u +"%Y-%m-%d %H:%M:%S") - - Testing: models/testing/modelId-${DUMMY_MODEL_ID}/${DUMMY_MODEL_NAME}/"
    echo "$(date -u +"%Y-%m-%d %H:%M:%S") - - Production: models/production/modelId-${DUMMY_MODEL_ID}/${DUMMY_MODEL_NAME}/"
}

# Execute main function
main "$@"

echo "$(date -u +"%Y-%m-%d %H:%M:%S") - $script_name completed"